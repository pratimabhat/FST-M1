package activities;

public class MyBook extends Book{

	public void setTitle(String s) {
	    title = s;
	}
}
