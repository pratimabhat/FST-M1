package activities;

public abstract class Book {
	
	String title;
	
	public void setTitle(String s) {
	
	}

	public String getTitle() {
	   return title;
	}
	
}
