package activities;

public class Activity5 {

	public static void main(String[] args) {
		
		MyBook newNovel = new MyBook();
		
		newNovel.setTitle("Learing Java");
		System.out.println("Title of the novel is : "+newNovel.getTitle());

	}

}
