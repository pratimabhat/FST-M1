tuple = (1,3,5,7,10,13,15,17)

print("Given tuple is : ", tuple)

print("Numbers divisible by 5 from the given tuple are : ")

for i in tuple:
    if(i%5 == 0):
        print(i)
