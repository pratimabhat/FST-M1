name = input("Enter your name : ")
age = int(input ("Enter your age : "))
print ("Hello "+ name +" You will be 100 years old in the year of "+str((2021-age)+100))