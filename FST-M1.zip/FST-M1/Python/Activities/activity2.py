number = int (input("Enter a number : "))
if (number % 2 )> 0 :
    print("This is a ODD number !")
else :
    print ("This is a EVEN number")

