numbers = [3,4,5,6,7]
list_size = len(numbers)

print ("List size is : ", list_size)

if (numbers[0] == numbers [list_size-1]):
    print("True")
else:
    print ("false")
