number = int(input("Input a number: "))

for i in range(1,number+1):
   print( str(i)*i)