package suiteExample;

import org.testng.annotations.Test;

public class DemoTwo {
  @Test
  public void demoTwo() {
	  System.out.println("This test case is from DemoTwo class.");
	  
  }
}