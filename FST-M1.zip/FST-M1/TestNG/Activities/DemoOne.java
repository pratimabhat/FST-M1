package suiteExample;

import org.testng.annotations.Test;

public class DemoOne {
  @Test
  public void firstTC() {
	  System.out.println("This is First test case.");
  }
  
  @Test
  public void secondTC() {
	  System.out.println("This is Second test case.");
  }
  
}
